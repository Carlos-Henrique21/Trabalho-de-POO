/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import jplay.Sprite;
import jplay.URL;

/**
 *
 * @author vitoria
 */
public class tiro extends Sprite {
    
    public tiro(int caminho, double y, double x) {
        super(URL.sprite("tiro.png"),12);
        this.y=y;
        this.x=x;
        this.caminho=caminho;
    }
    //direçoes do disparo
    protected static final int CIMA=4,DIREITA=2,ESQUERDA=1,PARAR=3,BAIXO=5;
    protected int caminho=PARAR;
    protected int direcao=3;
    protected static final int aceleracao=20;
    protected boolean movendo =false;
    void mover(){
        if(caminho==ESQUERDA){
            this.x-=aceleracao;
            if (direcao!=1){
                setSequence(3,6);
            }movendo=true;
        }
        else if(caminho==DIREITA){
            this.x+=aceleracao;
            if(direcao!=2){
                setSequence(6,9);
            }movendo=true;
        }else if(caminho == PARAR ){
            this.y+=aceleracao;
            if(direcao!=5){
                setSequence(0,3);
            }movendo=true;
        }else if(caminho == BAIXO ){
            this.y+=aceleracao;
            if(direcao!=5){
                setSequence(0,3);
            }movendo=true;
        }if(movendo){
            movendo=false;
            update();
        }
    }
}
