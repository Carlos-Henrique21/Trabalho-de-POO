/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import java.util.LinkedList;
import jplay.Scene;

/**
 *
 * @author vitoria
 */
public class Controledetiros {
    LinkedList<tiro> tiros= new LinkedList<>();
    void adicionaTiros(int caminho, double y, double x, Scene cena ){
        tiro tiro= new tiro(caminho,y,x);
        tiros.addFirst(tiro);
        cena.addOverlay(tiro);
    }
    void run(jogador2 segundojogador){
        for(int i=0;i<tiros.size();i++){
            tiro tiro=tiros.removeFirst();
            tiro.mover();
            tiros.addLast(tiro);
            if(tiro.collided(segundojogador)){
                tiro.x=10_000;
                segundojogador.vida -=250;
                Jogador.pontuacao+=250;
            }

        }
    }
}
