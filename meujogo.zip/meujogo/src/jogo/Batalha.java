
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import jplay.Keyboard;
import jplay.Scene;
import jplay.URL;
import jplay.Window;
import jogo.Jogador;

public class Batalha {
    private Window m;
    private Scene cena;
    private Jogador jogar; 
    private Keyboard teclado;
    private adversario h;
    public Batalha(Window window){
        m=window;
        cena= new Scene();
        cena.loadFromFile(URL.scenario("Batalha.scn"));
        jogar= new Jogador(540,300);
        teclado= m.getKeyboard();
        h=new adversario(300,300);
        run();
        }
        private void run(){
            while(true){
                cena.draw();
                jogar.controle(m,teclado);
                jogar.caminho(cena);
                h.caminho(cena);
                cena.moveScene(jogar);
                jogar.x += cena.getXOffset();
                jogar.y += cena.getYOffset();
                h.x += cena.getXOffset();
                h.y += cena.getYOffset();
                jogar.draw();
                h.draw();
                jogar.atirar(m,cena,teclado,h);
                h.andar(jogar.x, jogar.y);
                h.morre();
                h.atacar(jogar);
                jogar.vida(m);
                jogar.pontuacao(m);
                //jogar.mover(m);
                m.update();

        }
    
}}
