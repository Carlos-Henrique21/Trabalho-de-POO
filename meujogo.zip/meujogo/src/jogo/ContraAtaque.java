/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import jplay.Sprite;
import jplay.URL;

/**
 *
 * @author vitoria
 */
public class ContraAtaque extends Sprite {
    
    public ContraAtaque(int caminho, double y, double x) {
        super(URL.sprite("inimigo.png"),16);
        this.y=y;
        this.x=x;
        this.caminho=caminho;
    }
    //direçoes do disparo
    protected static final int DIREITA=2,ESQUERDA=1,PARAR=3;
    protected int caminho=PARAR;
    protected int direcao=3;
    protected static final int aceleracao=20;
    protected boolean movendo =false;
    void mover(){
        if(caminho==ESQUERDA){
            this.x-=aceleracao;
            if (direcao!=1){
                setSequence(9,12);
            }movendo=true;
        }
        else if(caminho==DIREITA){
            this.x+=aceleracao;
            if(direcao!=2){
                setSequence(5,8);
            }movendo=true;
        }else if(caminho == PARAR ){
            this.y+=aceleracao;
            if(direcao!=5){
                setSequence(0,3);
            }movendo=true;
        
        }if(movendo){
            movendo=false;
            update();
        }
    }
}
