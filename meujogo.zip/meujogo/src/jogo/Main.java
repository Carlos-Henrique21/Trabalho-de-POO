/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import jplay.GameImage;
import jplay.Keyboard;
import jplay.URL;
import jplay.Window;

/**
 *
 * @author vitoria
 */
public class Main {
    public static void main(String[]args){
        Window m;
        m= new Window(750,550);
        Keyboard clic = m.getKeyboard();
        JLabel label;
        JFrame frame;
        GameImage pmenu= new GameImage(URL.sprite("TelaInicial.png"));
        while(true){
            m.update();
            pmenu.draw();
            if(clic.keyDown(Keyboard.ENTER_KEY))
            {
                new Batalha(m);
            }
            } 
     
    
        }
}
    