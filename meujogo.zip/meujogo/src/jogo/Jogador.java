/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;



import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import jplay.Keyboard;
import jplay.Scene;
import jplay.URL;
import jplay.Window;


/**
 *
 * @author vitoria
 */
public class Jogador extends jogador2{

    static double vida=1000;
    static double pontuacao=0;
    
    public Jogador(int x, int y) {
        super(URL.sprite("jogador1.png"), 16);
        this.x = x;
        this.y=y;
        this.setTotalDuration(2000);
        
    }
    Controledetiros tiros=new Controledetiros();
    void atirar(Window m, Scene cena, Keyboard teclado, jogador2 segundojogador){
        if(teclado.keyDown(KeyEvent.VK_SPACE)){
            tiros.adicionaTiros(direcao,y + 15,x,cena);
        }
        tiros.run(segundojogador);
    }
    
    public void controle(Window m, Keyboard teclado){
        
        if(teclado.keyDown(Keyboard.LEFT_KEY)){
            if(this.x>0)
                this.x-=velocidade;
            if(direcao!=1){
                setSequence(5,8);
                direcao=1;
            }movendo=true;
        }else if(teclado.keyDown(Keyboard.RIGHT_KEY)){
            if(this.x<m.getWidth() - 60)
                this.x+=velocidade;
            if(direcao!=2){
                setSequence(12,16);
                direcao=2;
            }movendo=true;
        }else if(teclado.keyDown(Keyboard.UP_KEY)){
            if(this.y>0)
                this.y-=velocidade;
            if(direcao!=4){
                setSequence(0,4);
                direcao=4;
            }movendo=true;
        }else if(teclado.keyDown(Keyboard.DOWN_KEY)){
            if(this.y<m.getHeight() - 60)
                this.y+=velocidade;
            if(direcao!=5){
                setSequence(0,4);
                direcao=5;
            }
            movendo=true;
        }
        if(movendo){
            update();
            movendo= false;
        }
    }
    Font f = new Font("arial",Font.BOLD,30);
    public void vida(Window m){
        m.drawText("Vida " +Jogador.vida, 50, 50, Color.yellow, f);
    }
    public void pontuacao(Window m){
        m.drawText("Pontuacao " +Jogador.pontuacao, 20, 20, Color.yellow, f);
    }
    
//controle de percurso
    
    public int vida1;
    public int atk;
    public int def;
    
    public int getVida(){
        return vida1;     
    }
    public void setVida(int vida){
        this.vida1 = vida1;
    }
      
    public int getAtk(){
        return atk;
}
    public void setAtk(int atk){
        this.atk = atk;
    }
    public int getDef(){
        return def;    
    }
    public void setDef(int def){
        this.def = def;
    }
    

   

    
    
}
