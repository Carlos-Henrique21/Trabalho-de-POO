/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

import java.util.LinkedList;
import jplay.Scene;

/**
 *
 * @author vitoria
 */
public class controledeataquesinimigo {
    LinkedList<ContraAtaque> atqinimi= new LinkedList<>();
    void adicionaAtaques(int caminho, double y, double x, Scene cena ){
        ContraAtaque ataquesinimigo= new ContraAtaque(caminho,y,x);
        atqinimi.addFirst(ataquesinimigo);
        cena.addOverlay(ataquesinimigo);
    }
    void run(Jogador jogador1){
        for(int i=0;i<atqinimi.size();i++){
            ContraAtaque ataquesinimigo=atqinimi.removeFirst();
            ataquesinimigo.mover();
            atqinimi.addLast(ataquesinimigo);
            if(ataquesinimigo.collided(jogador1)){
                ataquesinimigo.x=10_000;
                jogador1.vida -=250;
                jogador1.pontuacao-=250;
            }

        }
    }
}