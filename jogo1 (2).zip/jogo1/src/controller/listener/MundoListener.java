package controller.listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import controller.AcessoBD;
import static view.MundoView.table_ViewMundo;
import static view.MundoView.*;
import view.MundoView;
import model.dao.MundoDAO;
import model.entity.Mundo;

public class MundoListener implements ActionListener{

	private static MundoDAO daoMundo;
	private static AcessoBD dbman;

	public void actionPerformed(ActionEvent e){
		
		dbman = new AcessoBD();
		daoMundo = new MundoDAO(dbman.getCon());
		
	
		
		if(e.getActionCommand().equals("CRUD")){
			MundoView mv;
			try {
				mv = new MundoView();
				mv.setVisible(true);
				mv.setResizable(false);
				mv.setLocationRelativeTo(null);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		
		if(e.getActionCommand().equals("Carregar mundos")){
			loadData();
		}
		
		if(e.getActionCommand().equals("Cadastrar")){
			try { 
				Mundo novoMundo = new Mundo(-1, NomeMundo.getText());
				String n = NomeMundo.getText();
				if(n.equals("")){
					JOptionPane.showMessageDialog(null, "Erro. Campo 'Nome' vazio.");
				}else{
					daoMundo.insert(novoMundo);
					JOptionPane.showMessageDialog(null, "Mundo '" + novoMundo.getNomeMundo() + "' inserido com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				}
				
				try {
					comboBox_SelectMundo.setModel(new DefaultComboBoxModel(daoMundo.getAll().toArray()));
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} 
			
			
			loadData();
			NomeMundo.setText("");
			CodigoMundo.setText("");
			NomeMundo.requestFocus();
		}
	
		if(e.getActionCommand().equals("Remover")){	
			try {
				String nome = comboBox_SelectMundo.getSelectedItem().toString();
				int id = 0;
				
				List<Mundo> listal = daoMundo.getAll();
				
				for (Mundo mundo : listal) {
					if(mundo.getNomeMundo().equals(nome)){
						id = mundo.getIdMundo();
						JOptionPane.showMessageDialog(null, "Mundo '" + mundo.getNomeMundo() + "' removido com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
					}	
				}
				
				daoMundo.delete(id);
				ArrayList<Mundo> arrMundo = daoMundo.getAll();
				comboBox_SelectMundo.setModel(new DefaultComboBoxModel(arrMundo.toArray()));
				
				if(comboBox_SelectMundo.getItemCount()==0) {
					JOptionPane.showMessageDialog(null, "Nao ha mundos.", "", JOptionPane.INFORMATION_MESSAGE);
				}				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			loadData();
			NomeMundo.setText("");
			CodigoMundo.setText("");
			NomeMundo.requestFocus();
		}
		
		if(e.getActionCommand().equals("Editar")){	
			try {			
				Mundo velhoMundo = (Mundo)comboBox_SelectMundo.getSelectedItem();
				Mundo novoMundo = new Mundo(null, NomeMundo.getText());
				String n = NomeMundo.getText();
				if(n.equals("")){
					JOptionPane.showMessageDialog(null, "Erro. Campo 'Nome' vazio.");
				}else{
					daoMundo.update(velhoMundo, novoMundo);
					JOptionPane.showMessageDialog(null, "Mundo '" + velhoMundo.getNomeMundo() + "' editado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				}
				int lastSelectedIndex = comboBox_SelectMundo.getSelectedIndex();
				ArrayList<Mundo> arrMundo = daoMundo.getAll();
				comboBox_SelectMundo.setModel(new DefaultComboBoxModel(arrMundo.toArray()));
				comboBox_SelectMundo.setSelectedIndex(lastSelectedIndex);
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			loadData();
			NomeMundo.setText("");
			CodigoMundo.setText("");
			NomeMundo.requestFocus();			
		}
		
		if(e.getActionCommand().equals("Limpar")){
			comboBox_SelectMundo.setSelectedItem(null);
			NomeMundo.setText("");
			CodigoMundo.setText("");
			NomeMundo.requestFocus();
		}
	}
		
		
		
		private void loadData(){
			DefaultTableModel dm = new MundoDAO(dbman.getCon()).getData();
			table_ViewMundo.setModel(dm);
		}
}

